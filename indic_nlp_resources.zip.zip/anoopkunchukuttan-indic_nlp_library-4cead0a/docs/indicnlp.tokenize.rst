tokenize Package
================

:mod:`indic_tokenize` Module
----------------------------

.. automodule:: indicnlp.tokenize.indic_tokenize
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`indic_detokenize` Module
------------------------------

.. automodule:: indicnlp.tokenize.indic_detokenize
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`sentence_tokenize` Module
----------------------------

.. automodule:: indicnlp.tokenize.sentence_tokenize
    :members:
    :undoc-members:
    :show-inheritance:
